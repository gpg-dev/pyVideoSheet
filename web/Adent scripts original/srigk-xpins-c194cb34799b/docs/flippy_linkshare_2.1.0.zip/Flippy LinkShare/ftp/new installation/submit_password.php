<?php
session_start();

include('db.php');


if($_POST)
{	
	
if(!isset($_SESSION['username'])){
	//Do Nothing
}else{
	
$UserName = $_SESSION['username'];

if($GetUser = $mysqli->query("SELECT * FROM users WHERE username='$UserName'")){

    $UserInfo = mysqli_fetch_array($GetUser);

	$UserId = $UserInfo['id'];
	
	$UserPassword = $UserInfo['password'];
	
    $GetUser->close();
	
}else{
    
	 printf("<div class='alert alert-danger alert-pull'>There seems to be an issue. Please Trey again</div>");
}

}
	$CurrentPassword = $_POST['inputCurrentPassword'];
	
	$EncryptCurrentPassword = md5($CurrentPassword);
	
	if ($EncryptCurrentPassword !== $UserPassword)
	{
		//required variables are empty
		die('<div class="alert alert-danger" role="alert">Existing password doesn&acute;t match.</div>');
	}
	
	if(!isset($_POST['inputPassword']) || strlen($_POST['inputPassword'])<1)
	{
		//required variables are empty
		die('<div class="alert alert-danger" role="alert">Please provide a password.</div>');
	}
	
	if(!isset($_POST['inputPassword']) || strlen($_POST['inputPassword'])<5)
	{
		//required variables are empty
		die('<div class="alert alert-danger" role="alert">New password must be least 6 characters long.</div>');
	}
		if(!isset($_POST['inputConfirmPassword']) || strlen($_POST['inputConfirmPassword'])< 1)
	{
		//required variables are empty
		die('<div class="alert alert-danger" role="alert">Please enter the same password as above.</div>');
	}
	
	if ($_POST['inputPassword']!== $_POST['inputConfirmPassword'])
 	{
		//required variables are empty
     	die('<div class="alert alert-danger" role="alert">Conform Password did not match! Try again.</div>');
 	
	}
	
		
	$Password  					= $mysqli->escape_string($_POST['inputPassword']); // Password
	$EncryptNewPassword         = md5($Password); // Encript Password
		
		
// Update info into database table.. do w.e!
		$mysqli->query("UPDATE users SET password='$EncryptNewPassword' WHERE id='$UserId'");
		
		
		die('<div class="alert alert-success" role="alert">Your password updated successfully.</div>');
		

   }else{
	   
   		die('<div class="alert alert-danger" role="alert">There seems to be a problem. Please try again.</div>');
   }
    


?>