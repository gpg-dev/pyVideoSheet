<footer class="main-footer">

<div class="container">
<div class="footer-text">Copyright &#169; <?php echo date("Y");?> <?php echo $settings['name'];?>. All Rights Reserved.</div>
</div><!--container-->

</footer>

</div><!--wrap-->

</body>
</html>