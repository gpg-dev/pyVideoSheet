<footer class="main-footer">

<span>Powered by</span> <a href="http://www.flippyscripts.com/">Flippy LinkShare</a><span>&#8482;</span> - <a href="http://www.flippyscripts.com/">FlippyScripts</a>

</footer><!--main-footer-->

</div><!--container-fluid-->
</div><!--wrap-->
</body>
</html>