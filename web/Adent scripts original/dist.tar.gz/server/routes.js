/**
 * Main application routes
 */

'use strict';

import errors from './components/errors';
import path from 'path';
import * as auth from './auth/auth.service';
import userController from './api/v1/userController';
import videoController from './api/v1/videoController';
import productController from './api/v1/productController';
import memberShipPackageController from './api/v1/memberShipPackageController';
import performerController from './api/v1/performerController';
import commentController from './api/v1/commentController';
import notificationController from './api/v1/notificationController';
import orderController from './api/v1/orderController';
import bookmarkController from './api/v1/bookmarkController';
import photoController from './api/v1/photoController';
import userTempController from './api/v1/userTempController';
import saveVideoController from './api/v1/saveVideoController';
import bannerController from './api/v1/bannerController';
import pageController from './api/v1/pageController';
import settingController from './api/v1/settingController';
import categoryController from './api/v1/categoryController';
import streamingController from './api/v1/streamingController';
import messageController from './api/v1/messageController';
import tipController from './api/v1/tipController';
import streamScheduleControler from './api/v1/streamScheduleController';
import tokenPackageController from './api/v1/tokenPackageController';
import purchasedItemController from './api/v1/purchasedItemController';
import blogController from './api/v1/blogController';
import productCategoryController from './api/v1/productCategoryController';
import paypalController from './api/v1/paypalController';
import bitpayController from './api/v1/bitpayController';
import couponController from './api/v1/couponController';
import searchController from './api/v1/searchController';
import albumController from './api/v1/albumController';

var multipart = require('connect-multiparty');
var multipartMiddleware = multipart();

export default function(app) {
  // Insert routes below
  app.get('/api/v1/users/me', auth.isAuthenticated(), userController.me);
  app.put('/api/v1/users/:id/password', auth.isAuthenticated(), userController.changePassword);
  app.put('/api/v1/users/:id/update-profile', auth.isAuthenticated(), userController.updateProfile);
  app.post('/api/v1/users/photo', auth.isAuthenticated(), multipartMiddleware, userController.updatePhoto);
  app.post('/api/v1/users', auth.hasRole('admin'),multipartMiddleware, userController.create);
  app.post('/api/v1/users/download', auth.isAuthenticated(), userController.downloadVideo);
  app.post('/api/v1/users/favorite', auth.isAuthenticated(), userController.favoriteVideo);
  app.put('/api/v1/users/favorite', auth.isAuthenticated(), userController.removeFavoriteVideo);
  app.post('/api/v1/users/watch-later', auth.isAuthenticated(), userController.watchLaterVideo);
  app.put('/api/v1/users/watch-later', auth.isAuthenticated(), userController.removeWatchLaterVideo);
  app.post('/api/v1/users/forgot', userController.forgot);
  app.delete('/api/v1/users/:id', auth.hasRole('admin'), userController.destroy);
  app.get('/api/v1/users/:id', auth.hasRole('admin'), userController.show);
  app.put('/api/v1/users/:id', auth.hasRole('admin'),multipartMiddleware, userController.update);
  app.get('/api/v1/users', auth.hasRole('admin'), userController.index);
  app.get('/api/v1/users/check/uservip',userController.checkVip);
  app.use('/auth', require('./auth'));

  //Create User Temp
  app.post('/api/v1/userTemps', userTempController.create);
  app.delete('/api/v1/userTemps/:id', userTempController.destroy);

  //CURD Blog
  app.get('/api/v1/blogs', blogController.index);
  app.post('/api/v1/blogs', auth.hasRole('admin'), multipartMiddleware, blogController.create);
  app.get('/api/v1/blogs/:id', blogController.show);
  app.put('/api/v1/blogs/:id',auth.hasRole('admin'),  multipartMiddleware, blogController.update);
  app.delete('/api/v1/blogs/:id',auth.hasRole('admin'),  blogController.destroy);

  //CURD Video
  app.post('/api/v1/videos', auth.hasRole('admin'), multipartMiddleware, videoController.create);
  app.post('/api/v1/videos/like', auth.isAuthenticated(),  videoController.like);
  app.get('/api/v1/videos', auth.loadUser(), videoController.index);
  app.get('/api/v1/videos/folder', auth.hasRole('admin'), videoController.folder);
  app.put('/api/v1/videos/:id',auth.hasRole('admin'), multipartMiddleware, videoController.update);
  app.delete('/api/v1/videos/:id',auth.hasRole('admin'),  videoController.destroy);
  app.get('/api/v1/videos/search', videoController.search);
  app.get('/api/v1/videos/:id', videoController.show);
  app.post('/api/v1/videos/:id/images', auth.hasRole('admin'), multipartMiddleware, videoController.uploadMoreImage);
  app.get('/api/v1/videos/:id/images', videoController.getListMoreImages);
  app.delete('/api/v1/videos/images/:id', auth.hasRole('admin'), videoController.removeMoreImage);

  //CURD Photo
  app.post('/api/v1/photos', auth.hasRole('admin'), multipartMiddleware, photoController.create);
  app.get('/api/v1/photos', photoController.index);
  app.get('/api/v1/photos/all', photoController.all);
  app.put('/api/v1/photos/:id',auth.hasRole('admin'), multipartMiddleware, photoController.update);
  app.delete('/api/v1/photos/:id',auth.hasRole('admin'),  photoController.destroy);
  app.get('/api/v1/photos/search', auth.loadUser(), photoController.search);
  app.get('/api/v1/photos/:id', photoController.show);

  //CURD Banner
  app.post('/api/v1/banners', auth.hasRole('admin'), multipartMiddleware, bannerController.create);
  app.get('/api/v1/banners', bannerController.index);
  app.put('/api/v1/banners/:id',auth.hasRole('admin'), multipartMiddleware, bannerController.update);
  app.delete('/api/v1/banners/:id',auth.hasRole('admin'),  bannerController.destroy);
  app.get('/api/v1/banners/:id', bannerController.show);

  //CURD Page
  app.post('/api/v1/pages', auth.hasRole('admin'), multipartMiddleware, pageController.create);
  app.get('/api/v1/pages',pageController.index);
  app.put('/api/v1/pages/:id',auth.hasRole('admin'), multipartMiddleware, pageController.update);
  app.delete('/api/v1/pages/:id',auth.hasRole('admin'),  pageController.destroy);
  app.get('/api/v1/pages/:id', pageController.show);

  //CURD Categories
  app.post('/api/v1/categories', auth.hasRole('admin'), multipartMiddleware, categoryController.create);
  app.get('/api/v1/categories',categoryController.index);
  app.put('/api/v1/categories/:id',auth.hasRole('admin'), multipartMiddleware, categoryController.update);
  app.delete('/api/v1/categories/:id',auth.hasRole('admin'),  categoryController.destroy);
  app.get('/api/v1/categories/:id', categoryController.show);

  //CURD Setting
  app.post('/api/v1/settings', auth.hasRole('admin'), multipartMiddleware, settingController.create);
  app.get('/api/v1/settings', auth.hasRole('admin'),settingController.index);
  app.put('/api/v1/settings/:id',auth.hasRole('admin'), multipartMiddleware, settingController.update);
  app.delete('/api/v1/settings/:id',auth.hasRole('admin'),  settingController.destroy);
  app.get('/api/v1/settings/:id', auth.hasRole('admin'), settingController.show);
  app.get('/api/v1/settings/get/full', settingController.getSetting);

  //CURD Product
  app.post('/api/v1/products', auth.hasRole('admin'),  multipartMiddleware, productController.create);
  app.get('/api/v1/products', productController.index);
  app.put('/api/v1/products/:id', auth.hasRole('admin'), multipartMiddleware, productController.update);
  app.delete('/api/v1/products/:id', auth.hasRole('admin'),  productController.destroy);
  app.get('/api/v1/products/count', productController.countAllProducts);
  app.get('/api/v1/products/:id', productController.show);
  app.post('/api/v1/products/:id/images', auth.hasRole('admin'), multipartMiddleware, productController.uploadMoreImage);
  app.get('/api/v1/products/:id/images', productController.getListMoreImages);
  app.delete('/api/v1/products/images/:id', auth.hasRole('admin'), productController.removeMoreImage);

  //Save Video
  app.post('/api/v1/saveVideos', auth.isAuthenticated(), saveVideoController.create);
  app.get('/api/v1/saveVideos', auth.isAuthenticated(),saveVideoController.index);
  app.put('/api/v1/saveVideos/:id', auth.isAuthenticated(), saveVideoController.update);
  app.delete('/api/v1/saveVideos/:id', auth.isAuthenticated(),  saveVideoController.destroy);
  app.get('/api/v1/saveVideos/:id', auth.isAuthenticated(),saveVideoController.show);

   //CURD Member Ship Package
  app.post('/api/v1/memberShipPackages', auth.hasRole('admin'), multipartMiddleware, memberShipPackageController.create);
  app.get('/api/v1/memberShipPackages', memberShipPackageController.index);
  app.put('/api/v1/memberShipPackages/:id',auth.hasRole('admin'), multipartMiddleware, memberShipPackageController.update);
  app.delete('/api/v1/memberShipPackages/:id',auth.hasRole('admin'),  memberShipPackageController.destroy);
  app.get('/api/v1/memberShipPackages/:id', memberShipPackageController.show);

   //CURD Performer
  app.post('/api/v1/performers', auth.hasRole('admin'), multipartMiddleware, performerController.create);
  app.get('/api/v1/performers', performerController.index);
  app.put('/api/v1/performers/:id', auth.hasRole('admin'), multipartMiddleware, performerController.update);
  app.delete('/api/v1/performers/:id', auth.hasRole('admin'),  performerController.destroy);
  app.get('/api/v1/performers/me', auth.hasRole('model'), performerController.me);
  app.get('/api/v1/performers/unassigned/users', auth.hasRole('admin'), performerController.findUnassignedUsers);
  app.get('/api/v1/performers/assignedUsers', auth.hasRole('admin'), performerController.findAssignedPerformers);
  app.get('/api/v1/performers/search', performerController.search);
  app.get('/api/v1/performers/:id', performerController.show);
  app.put('/api/v1/performers/:id/settings', auth.hasRole('model'), performerController.updateSetting);
  app.get('/api/v1/performers/users/:userId', performerController.findByUserId);
  app.put('/api/v1/performers/:id/assignUser', auth.hasRole('admin'), performerController.assignUser);

  //CURD Comment
  app.post('/api/v1/comments', auth.isAuthenticated(),  commentController.create);
  app.get('/api/v1/comments', commentController.index);
  app.put('/api/v1/comments/:id', auth.isAuthenticated(),  commentController.update);
  app.delete('/api/v1/comments/:id', auth.isAuthenticated(),  commentController.destroy);
  app.get('/api/v1/comments/:id', commentController.show);

  //CURD Notification
  app.post('/api/v1/notifications', auth.isAuthenticated(),  notificationController.create);
  app.get('/api/v1/notifications', notificationController.index);
  app.put('/api/v1/notifications/:id', auth.isAuthenticated(),  notificationController.update);
  app.delete('/api/v1/notifications/:id', auth.isAuthenticated(),  notificationController.destroy);
  app.get('/api/v1/notifications/:id', notificationController.show);

  //CURD Bookmark
  app.post('/api/v1/bookmarks', auth.isAuthenticated(),  bookmarkController.create);
  app.get('/api/v1/bookmarks', auth.isAuthenticated(), bookmarkController.index);
  app.put('/api/v1/bookmarks/:id', auth.isAuthenticated(),  bookmarkController.update);
  app.delete('/api/v1/bookmarks/:id', auth.isAuthenticated(),  bookmarkController.destroy);
  app.get('/api/v1/bookmarks/:id', auth.isAuthenticated(), bookmarkController.show);

  //CURD Order
  app.post('/api/v1/orders', auth.isAuthenticated(),  orderController.create);
  app.get('/api/v1/orders', auth.isAuthenticated(), orderController.index);
  app.put('/api/v1/orders/:id', auth.isAuthenticated(),  orderController.update);
  app.delete('/api/v1/orders/:id', auth.isAuthenticated(),  orderController.destroy);
  app.get('/api/v1/orders/:id', orderController.show);

  //Update Member Ship
  app.post('/payment-success',userController.updateMemberShip);
  app.post('/buy-success',userController.payment);

  //streaming
  app.post('/api/v1/streaming/sessions', auth.isAuthenticated(), streamingController.createSession);
  app.post('/api/v1/streaming/:id/snapshot', auth.isAuthenticated(), streamingController.findSessionMiddleware, streamingController.createSnapshot);
  app.get('/api/v1/streaming', streamingController.getActiveStreams);
  app.get('/api/v1/streaming/active', streamingController.getActiveStream);
  app.delete('/api/v1/streaming/:id', auth.isAuthenticated(), streamingController.findSessionMiddleware, streamingController.deactivateStream);
  app.post('/api/v1/streaming/:id/purchase', auth.isAuthenticated(), streamingController.purchase);
  app.post('/api/v1/streaming/:id/purchase/check', auth.isAuthenticated(), streamingController.checkPurchased);
  app.put('/api/v1/streaming/:id/status', auth.isAuthenticated(), streamingController.findSessionMiddleware, streamingController.updateStatus);
  app.get('/api/v1/streaming/purchase/count', streamingController.countPurchaser);
  //message
  app.post('/api/v1/messages', auth.isAuthenticated(), messageController.findSessionMiddleware, messageController.createMessage);
  app.get('/api/v1/messages', messageController.listMessages);
  //tips
  app.post('/api/v1/tips', auth.isAuthenticated(), tipController.addTip);
  app.get('/api/v1/tips', auth.isAuthenticated(), tipController.history);
  app.get('/api/v1/tips/statistic', auth.isAuthenticated(), tipController.statistic);

  //schedule
  app.post('/api/v1/schedule', auth.isAuthenticated(), streamScheduleControler.create);
  app.put('/api/v1/schedule/:id', auth.isAuthenticated(), streamScheduleControler.update);
  app.delete('/api/v1/schedule/:id', auth.isAuthenticated(), streamScheduleControler.delete);
  app.get('/api/v1/schedule', auth.loadUser(), streamScheduleControler.list);

  //tokens manager
  app.post('/api/v1/tokens/packages', auth.hasRole('admin'), tokenPackageController.create);
  app.put('/api/v1/tokens/packages/:id', auth.hasRole('admin'), tokenPackageController.findPackageMiddleware, tokenPackageController.update);
  app.delete('/api/v1/tokens/packages/:id', auth.hasRole('admin'), tokenPackageController.findPackageMiddleware, tokenPackageController.delete);
  app.get('/api/v1/tokens/packages/:id', tokenPackageController.findPackageMiddleware, tokenPackageController.show);
  app.get('/api/v1/tokens/packages', tokenPackageController.list);

  app.post('/api/v1/purchasedItems', auth.isAuthenticated(), purchasedItemController.purchase);
  app.post('/api/v1/purchasedItems/check', auth.isAuthenticated(), purchasedItemController.checkPurchase);

  app.post('/api/v1/product-categories', auth.hasRole('admin'),  productCategoryController.create);
  app.put('/api/v1/product-categories/:id', auth.hasRole('admin'), productCategoryController.middlewares.findOne, productCategoryController.update);
  app.delete('/api/v1/product-categories/:id', auth.hasRole('admin'), productCategoryController.middlewares.findOne, productCategoryController.delete);
  app.get('/api/v1/product-categories', auth.loadUser(), productCategoryController.list);
  app.get('/api/v1/product-categories/:id', productCategoryController.middlewares.findOne, productCategoryController.findOne);
  //payment by paypal
  app.post('/api/v1/paypal/payment', auth.isAuthenticated(), paypalController.init, paypalController.doDirectPayment);
  app.post('/api/v1/paypal/signup', paypalController.init, paypalController.doDirectPayment);
  app.post('/api/v1/paypal/callback', paypalController.init, paypalController.updateTransaction);

  //payment by bitpay
  app.post('/api/v1/bitpay/payment', auth.isAuthenticated(), bitpayController.init, bitpayController.doDirectPayment);
  app.post('/api/v1/bitpay/signup', bitpayController.init, bitpayController.doDirectPayment);
  app.post('/api/v1/bitpay/callback', bitpayController.init, bitpayController.updateTransaction);

  app.post('/api/v1/coupons', auth.hasRole('admin'),  couponController.create);
  app.put('/api/v1/coupons/:id', auth.hasRole('admin'), couponController.middlewares.findOne, couponController.update);
  app.delete('/api/v1/coupons/:id', auth.hasRole('admin'), couponController.middlewares.findOne, couponController.delete);
  app.get('/api/v1/coupons', auth.hasRole('admin'), couponController.list);
  app.get('/api/v1/coupons/:id', auth.hasRole('admin'), couponController.middlewares.findOne, couponController.findOne);
  app.get('/api/v1/coupon', couponController.findByCode);

  app.get('/api/v1/search/stats', searchController.stats);
  app.get('/api/v1/search', searchController.findItems);

  app.post('/api/v1/albums', auth.hasRole('admin'),  albumController.create);
  app.put('/api/v1/albums/:id', auth.hasRole('admin'), albumController.middlewares.findOne, albumController.update);
  app.delete('/api/v1/albums/:id', auth.hasRole('admin'), albumController.middlewares.findOne, albumController.delete);
  app.get('/api/v1/albums', albumController.list);
  app.get('/api/v1/albums/all', albumController.findAllPerfomerAlbums);
  app.get('/api/v1/albums/count', albumController.countAllAlbums);
  app.get('/api/v1/albums/:id', albumController.middlewares.findOne, albumController.findOne);

  // All undefined asset or api routes should return a 404
  app.route('/:url(api|auth|components|app|bower_components|assets|lib|styles)/*')
   .get(errors[404]);
   app.route('/backend/*')
    .get((req, res) => {
      res.sendFile(path.resolve('backend/index.html'));
    });
  // All other routes should redirect to the index.html
  app.route('/*')
    .get((req, res) => {
      res.sendFile(path.resolve(app.get('appPath') + '/index.html'));
    });

}
