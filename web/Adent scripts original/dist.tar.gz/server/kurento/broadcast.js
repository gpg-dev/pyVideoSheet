var minimist = require('minimist');
var ws = require('ws');
var kurento = require('kurento-client');
var argv = minimist(process.argv.slice(2), {
  default: {
    as_uri: 'https://localhost:8443/',
    ws_uri: 'ws://localhost:8888/kurento'
  }
});

/*
 * Definition of global variables.
 */
var idCounter = 0;
var candidatesQueue = {};
var kurentoClient = null;
var presenters = {};
var viewers = {}; //TODO - support other store such as redis
var noPresenterMessage = 'No active presenter. Try again later...';
var DEBUG = false;
/**
* pass express server
*/
module.exports = function(server, options) {
  if (!options) {
    options = {};
  }
  if (options.as_uri) {
    argv.as_uri = options.as_uri;
  }
  if (options.ws_uri) {
    argv.ws_uri = options.ws_uri;
  }

  var wss = new ws.Server({
    server: server,
    path: '/broadcast'
  });

  function nextUniqueId() {
    //idCounter++;
    //return idCounter.toString();
    return Math.random().toString(36).substring(7);
  }

  /*
   * Management of WebSocket messages
   */
  wss.on('connection', function(ws) {
    var sessionId = nextUniqueId();
    DEBUG && console.log('Connection received with sessionId ' + sessionId);

    //emit sessionId to client

    ws.on('error', function(error) {
      stop(sessionId);
    });

    ws.on('close', function() {
      stop(sessionId);
    });

    ws.on('message', function(_message) {
      var message = JSON.parse(_message);
      DEBUG && console.log('Connection ' + sessionId + ' received message ', message);

      switch (message.id) {
        case 'initSession':
          //TODO - check for unique session ID
          if (!message.sessionId) {
            sessionId = Math.random().toString(36).substring(7);
          } else {
            sessionId = message.sessionId;
          }
          return ws.send(JSON.stringify({
            id: 'initSession',
            response: 'accepted',
            sessionId: sessionId
          }));
        case 'presenter':
          startPresenter(sessionId, ws, message.sdpOffer, function(error, sdpAnswer) {
            if (error) {
              return ws.send(JSON.stringify({
                id: 'presenterResponse',
                response: 'rejected',
                message: error
              }));
            }
            ws.send(JSON.stringify({
              id: 'presenterResponse',
              response: 'accepted',
              sdpAnswer: sdpAnswer
            }));
          });
          break;

        case 'viewer':
          startViewer(sessionId, message.broadcastSessionId, ws, message.sdpOffer, function(error, sdpAnswer) {
            if (error) {
              return ws.send(JSON.stringify({
                id: 'viewerResponse',
                response: 'rejected',
                message: error
              }));
            }

            ws.send(JSON.stringify({
              id: 'viewerResponse',
              response: 'accepted',
              sdpAnswer: sdpAnswer
            }));
          });
          break;

        case 'stop':
          stop(sessionId);
          break;

        case 'onIceCandidate':
          onIceCandidate(sessionId, message.candidate);
          break;

        default:
          ws.send(JSON.stringify({
            id: 'error',
            message: 'Invalid message ' + message
          }));
          break;
      }
    });
  });

  //export util functions
  return {
    getPresenters: function() {
      return presenters();
    },

    getViewers: function(sessionId) {
      return sessionId ? viewers[sessionId] : viewers;
    }
  };
};

/*
 * Definition of functions
 */

// Recover kurentoClient for the first time.
function getKurentoClient(callback) {
  if (kurentoClient !== null) {
    return callback(null, kurentoClient);
  }

  kurento(argv.ws_uri, function(error, _kurentoClient) {
    if (error) {
      DEBUG && console.log("Could not find media server at address " + argv.ws_uri);
      return callback("Could not find media server at address" + argv.ws_uri +
        ". Exiting with error " + error);
    }

    kurentoClient = _kurentoClient;
    callback(null, kurentoClient);
  });
}

function startPresenter(sessionId, ws, sdpOffer, callback) {
  clearCandidatesQueue(sessionId);

  presenters[sessionId] = {
    id: sessionId,
    pipeline: null,
    webRtcEndpoint: null
  };

  getKurentoClient(function(error, kurentoClient) {
    if (error) {
      stop(sessionId);
      return callback(error);
    }

    if (presenters[sessionId] === null) {
      stop(sessionId);
      return callback(noPresenterMessage);
    }

    kurentoClient.create('MediaPipeline', function(error, pipeline) {
      if (error) {
        stop(sessionId);
        return callback(error);
      }

      if (presenters[sessionId] === null) {
        stop(sessionId);
        return callback(noPresenterMessage);
      }

      presenters[sessionId].pipeline = pipeline;
      pipeline.create('WebRtcEndpoint', function(error, webRtcEndpoint) {
        if (error) {
          stop(sessionId);
          return callback(error);
        }

        if (presenters[sessionId] === null) {
          stop(sessionId);
          return callback(noPresenterMessage);
        }

        presenters[sessionId].webRtcEndpoint = webRtcEndpoint;

        if (candidatesQueue[sessionId]) {
          while (candidatesQueue[sessionId].length) {
            var candidate = candidatesQueue[sessionId].shift();
            webRtcEndpoint.addIceCandidate(candidate);
          }
        }

        webRtcEndpoint.on('OnIceCandidate', function(event) {
          var candidate = kurento.getComplexType('IceCandidate')(event.candidate);
          ws.send(JSON.stringify({
            id: 'iceCandidate',
            candidate: candidate
          }));
        });

        webRtcEndpoint.processOffer(sdpOffer, function(error, sdpAnswer) {
          if (error) {
            stop(sessionId);
            return callback(error);
          }

          if (presenters[sessionId] === null) {
            stop(sessionId);
            return callback(noPresenterMessage);
          }

          callback(null, sdpAnswer);
        });

        webRtcEndpoint.gatherCandidates(function(error) {
          if (error) {
            stop(sessionId);
            return callback(error);
          }
        });
      });
    });
  });
}

/**
* first params is viewer session id
*/
function startViewer(sessionId, broadcastSessionId, ws, sdpOffer, callback) {
  clearCandidatesQueue(sessionId);

  if (!presenters[broadcastSessionId] || !presenters[broadcastSessionId].pipeline) {
    stop(sessionId);
    return callback(noPresenterMessage);
  }

  presenters[broadcastSessionId].pipeline.create('WebRtcEndpoint', function(error, webRtcEndpoint) {
    if (error) {
      stop(sessionId);
      return callback(error);
    }
    if (!viewers[broadcastSessionId]) {
      viewers[broadcastSessionId] = {};
    }
    viewers[broadcastSessionId][sessionId] = {
      "webRtcEndpoint": webRtcEndpoint,
      "ws": ws
    };

    if (!presenters[broadcastSessionId]) {
      stop(sessionId);
      return callback(noPresenterMessage);
    }

    if (candidatesQueue[sessionId]) {
      while (candidatesQueue[sessionId].length) {
        var candidate = candidatesQueue[sessionId].shift();
        webRtcEndpoint.addIceCandidate(candidate);
      }
    }

    webRtcEndpoint.on('OnIceCandidate', function(event) {
      var candidate = kurento.getComplexType('IceCandidate')(event.candidate);
      ws.send(JSON.stringify({
        id: 'iceCandidate',
        candidate: candidate
      }));
    });

    webRtcEndpoint.processOffer(sdpOffer, function(error, sdpAnswer) {
      if (error) {
        stop(sessionId);
        return callback(error);
      }
      if (!presenters[broadcastSessionId]) {
        stop(sessionId);
        return callback(noPresenterMessage);
      }

      presenters[broadcastSessionId].webRtcEndpoint.connect(webRtcEndpoint, function(error) {
        if (error) {
          stop(sessionId);
          return callback(error);
        }
        if (presenters[broadcastSessionId] === null) {
          stop(sessionId);
          return callback(noPresenterMessage);
        }

        callback(null, sdpAnswer);
        webRtcEndpoint.gatherCandidates(function(error) {
          if (error) {
            stop(sessionId);
            return callback(error);
          }
        });
      });
    });
  });
}

function clearCandidatesQueue(sessionId) {
  if (candidatesQueue[sessionId]) {
    delete candidatesQueue[sessionId];
  }
}

function stop(sessionId) {
  if (presenters[sessionId] && presenters[sessionId].id === sessionId) {
    for (var i in viewers[sessionId]) {
      var viewer = viewers[sessionId][i];
      if (viewer && viewer.ws) {
        try {
          viewer.ws.send(JSON.stringify({
            id: 'stopCommunication'
          }));
        } catch (e) {
          DEBUG && console.log(e);
        }
      }
    }
    presenters[sessionId].pipeline && presenters[sessionId].pipeline.release();
    delete presenters[sessionId];
    //do not reset all viewers, just reset viewers of this presenters
    delete viewers[sessionId];
  } else {
    for (var k in viewers) {
      for (var j in viewers[k]) {
        if (j !== sessionId) {
          continue;
        }

        viewers[k][j].webRtcEndpoint && viewers[k][j].webRtcEndpoint.release();
        delete viewers[k][j];
      }
    }
  }

  clearCandidatesQueue(sessionId);

  //no presenters, close client
  if (Object.keys(presenters).length === 0 && presenters.constructor === Object) {
    DEBUG && console.log('Closing kurento client');
    kurentoClient && kurentoClient.close();
    kurentoClient = null;
  }
}

function onIceCandidate(sessionId, _candidate) {
  var candidate = kurento.getComplexType('IceCandidate')(_candidate);

  if (presenters[sessionId] && presenters[sessionId].id === sessionId && presenters[sessionId].webRtcEndpoint) {
    presenters[sessionId].webRtcEndpoint.addIceCandidate(candidate);
  } else if (viewers[sessionId] && viewers[sessionId].webRtcEndpoint) {
    viewers[sessionId].webRtcEndpoint.addIceCandidate(candidate);
  } else {
    if (!candidatesQueue[sessionId]) {
      candidatesQueue[sessionId] = [];
    }
    candidatesQueue[sessionId].push(candidate);
  }
}
