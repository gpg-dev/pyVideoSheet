'use strict';
import path from 'path';

exports = module.exports = {
  // List of user roles
  userRoles: ['guest', 'user', 'admin'],
  socketUrl:  process.env.SOCKET_URL || 'http://localhost:9000',
  version: require(path.join(__dirname, '..', '..', '..', 'package.json')).version,
  buildNumber: require(path.join(__dirname, '..', '..', '..', 'package.json')).buildNumber,
  enableRTMP: false,
  showBuild: true
};
