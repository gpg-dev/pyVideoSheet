'use strict';

// Production specific configuration
// =================================
var _path = require('path');

var _path2 = _interopRequireDefault(_path);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

module.exports = {
  app: {
    name: 'xmodels'
  },
  baseUrl: process.env.BASE_URL || 'http://localhost:9000/',
  // Server IP
  ip:     process.env.OPENSHIFT_NODEJS_IP ||
          process.env.IP ||
          undefined,

  // Server port
  port:   process.env.OPENSHIFT_NODEJS_PORT ||
          process.env.PORT ||
          8080,

  // MongoDB connection options
  mongo: {
    uri:  process.env.MONGODB_URI ||
          process.env.MONGOHQ_URL ||
          process.env.OPENSHIFT_MONGODB_DB_URL +
          process.env.OPENSHIFT_APP_NAME ||
          'mongodb://localhost/xmember'
  },
  redis: {
    port: 6379,
    host: '127.0.0.1',
    db: 3, // if provided select a non-default redis db
    options: {
      // see https://github.com/mranney/node_redis#rediscreateclient
    }
  },
  //AWS key
  AWS: {
    //http://docs.aws.amazon.com/AWSSimpleQueueService/latest/SQSGettingStartedGuide/AWSCredentials.html
    //chiizdev
    accessKeyId: 'xxx',
    secretAccessKey: 'xxx',
    region: 'us-east-1'
  },
  S3: {
    bucket: 'chiiz-assets'
  },
  emailFrom: 'noreply@app.com',
  //more config at https://github.com/nodemailer/nodemailer
  mailer: {
    host: 'smtp.gmail.com',
    port: 465,
    secure: true, // use SSL
    auth: {
      user: 'xxxx@gmail.com',
      pass: 'xxx'
    }
  },
  sessionSecret: 'app-secret',
  ES: {
    provider: 'aws',
    region: 'us-east-1',
    hosts: 'https://xxx.us-east-1.es.amazonaws.com',
    accessKeyId: null, //null will get AWS key
    secretAccessKey: null //null will get AWS key
  },
  //set / at the end
  avatarTempFolder: _path2.default.resolve(__dirname, '../../../client/assets/avatars/'),
  imageTempFolder: _path2.default.resolve(__dirname, '../../../client/uploads/images/'),
  fileTempFolder: _path2.default.resolve(__dirname, '../../../client/uploads/files/'),
  clientFolder: _path2.default.resolve(__dirname, '../../../client/'),
  imageSmallSize: { width: 130, height: 100 },
  imageMediumSize: { width: 320, height: 240 },
  imageModelSmallSize: { width: 130, height: 180 },
  imageModelMediumSize: { width: 275, height: 350 },
  avatarSmallSize: { width: 135, height: 135 },
  avatarMediumSize: { width: 315, height: 315 },
  imageType: 'direct', //s3 or direct
  fileType: 'direct', //s3 or direct
  avatarTempBaseUrl: '/assets/avatars/',
  watermarkFile: _path2.default.resolve(__dirname, '../../assets/watermark.png'),
  tmpFolder: _path2.default.resolve(__dirname, '../../assets/.tmp'),
  useCluster: false,
  useLiverload: false,
  xssProtection: false
};
