'use strict';

import mongoose, { Schema } from 'mongoose';

var TokenPackageSchema = new Schema({
  title: { type: String, required: true },
  description: { type: String, required: true },
  price: { type: Number },
  salePrice: { type: Number },
  token: { type: Number, required: true },
  isActive: {
    type: Boolean,
    default: true
  },
  createdAt: {
  	type: Date, default: Date.now
  },
  updatedAt: {
  	type: Date, default: Date.now
  }
}, {
  collection: 'tokenPackages',
  restrict: true,
  minimize: false
});

module.exports = mongoose.model('TokenPackage', TokenPackageSchema);
