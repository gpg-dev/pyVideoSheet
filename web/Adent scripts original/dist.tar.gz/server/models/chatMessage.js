'use strict';

import mongoose from 'mongoose';
mongoose.Promise = require('bluebird');
import { Schema } from 'mongoose';

var MessageSchema = new Schema({
  senderId: mongoose.Schema.Types.ObjectId,
  streamId: mongoose.Schema.Types.ObjectId,
  streamerId: mongoose.Schema.Types.ObjectId,
  type: {
    type: String,
    enum: ['chat', 'tip'],
    default: 'chat'
  },
  text: String,
  token: Number, //token for the tip
  meta: mongoose.Schema.Types.Mixed,
  sender: mongoose.Schema.Types.Mixed,
  createdAt: {
  	type: Date, default: Date.now
  }
}, {
  collection: 'chatmessages',
  restrict: true,
  minimize: false
});

module.exports = mongoose.model('ChatMessage', MessageSchema);
