'use strict';

import mongoose, {
  Schema
} from 'mongoose';

var ImageSchema = new Schema({
  name: String,
  imageFullPath: String,
  imageThumbPath: String,
  imageMediumPath: String,
  imageType: {
    type: String,
    enum: ['s3', 'direct']
  },
  parentObjectName: {
    type: String,
    default: 'product'
  },
  parentObjectId: { type: mongoose.Schema.Types.ObjectId },
  createdAt: {
    type: Date,
    default: Date.now
  },
  updatedAt: {
    type: Date,
    default: Date.now
  }
}, {
  collection: 'images',
  restrict: true,
  minimize: false
});

/**
 * Pre-save hook
 */
ImageSchema
  .pre('save', function(next) {
    if (this.isNew) {
      this.createdAt = new Date();
      this.updatedAt = new Date();
    } else {
      this.updatedAt = new Date();
    }
    next();
  });

module.exports = mongoose.model('ImageModel', ImageSchema);
