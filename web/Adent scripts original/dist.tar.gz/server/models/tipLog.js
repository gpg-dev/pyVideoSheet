'use strict';

import mongoose from 'mongoose';
import { Schema } from 'mongoose';
mongoose.Promise = require('bluebird');

var schema = new Schema({
  userId: mongoose.Schema.Types.ObjectId,
  user: mongoose.Schema.Types.Mixed, //user info
  streamerId: mongoose.Schema.Types.ObjectId, //this is user id
  streamId: mongoose.Schema.Types.ObjectId,
  token: Number,
  createdAt: {
  	type: Date, default: Date.now
  },
  updatedAt: {
  	type: Date, default: Date.now
  }
}, {
  collection: 'tipLogs',
  restrict: true,
  minimize: false
});

module.exports = mongoose.model('TipLog', schema);
