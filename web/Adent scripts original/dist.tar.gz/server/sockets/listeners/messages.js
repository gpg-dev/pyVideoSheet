module.exports = function(socketComponent) {
  
}
