import { Queue } from '../components';

//import email queue
require('./emails')(Queue);
require('./search')(Queue);