'use strict';

angular.module('xMember').directive('tipbox', function($timeout, Auth, tipService) {
  return {
    templateUrl: 'app/chat/views/tipbox.html',
    restrict: 'E',
    scope: {
      options: '='
    },
    link(scope) {
      scope.streamerId = scope.options.streamerId;
      var currentUser = Auth.getCurrentUser();
      scope.currentUser = currentUser;
      scope.tipAmount = 1; //TODO - set min tip
      scope.isDisableTipAmount = false; //TODO - update me
      scope.availableToken = currentUser.availableToken || 0;
      var activeStream = null;

      scope.$watch('options', function(nv) {
        if (nv && nv.stream) {
          activeStream = nv.stream;
        }
      });

      scope.sendTip = function(amount) {
        amount = amount || scope.tipAmount;
        if (!amount || amount < 0) {
          return;
        }

        var item = {
          streamerId: scope.streamerId,
          streamId: scope.options.stream ? scope.options.stream._id : '',
          token: amount,
          type: 'tip'
        };

        scope.isDisableTipAmount = true;
        tipService.create(item).then(resp => {
          scope.isDisableTipAmount = false;
          scope.availableToken = resp.availableToken;
        })
        .catch(err => scope.isDisableTipAmount = false);
      };
    }
  };
});
