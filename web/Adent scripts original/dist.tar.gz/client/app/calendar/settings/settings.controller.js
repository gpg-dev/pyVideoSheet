/* global angular */

class ModelSettingsCtrl {
  constructor(perfomerService, performer) {
    //load performer infomation
    this.settings = performer.settings;
    this.service = perfomerService;
    this.performer = performer;
  }

  update() {
    this.service.updateSetting(this.performer._id, this.settings)
    .then(resp => alert('Updated!'));
  }
}

angular.module('xMember')
  .controller('ModelSettingsCtrl', ModelSettingsCtrl);
