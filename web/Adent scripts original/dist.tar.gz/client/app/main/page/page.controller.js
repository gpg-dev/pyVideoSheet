"use strict";
angular.module('xMember').controller('PageViewCtrl', function ($scope, page) {
  $scope.page = page;
});

