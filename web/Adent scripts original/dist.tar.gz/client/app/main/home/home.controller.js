'use strict';
(function() {

  class HomeController {
    constructor($http,$state, $scope) {
    }
  }

  angular.module('xMember')
    .controller('HomeCtrl', HomeController);
})();
