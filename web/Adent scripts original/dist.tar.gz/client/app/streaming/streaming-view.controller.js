/* global StreamingBroadcast, alert, angular */

class StreamingViewCtrl {
  constructor($scope, $element, $timeout, $stateParams, $uibModal, Auth, streamingService, socket, growl, activeStream, currentUser) {
    this.videoElem = $element.find('.video')[0];
    this.sessionId = null;
    this.streaming = null;
    this.service = streamingService;
    this.play = this.play.bind(this);
    this.manageSocketEvent = this.manageSocketEvent.bind(this);
    this.activeStream = activeStream;
    this.chatOptions = {
      streamerId: $stateParams.id,
      stream: activeStream
    };
    this.modal = $uibModal;
    this.$scope = $scope;
    this.socket = socket;
    this.status = activeStream ? activeStream.status : '';
    this.growl = growl;
    this.totalJoined = 0;
    this.socket = socket;
    var _this = this;

    //TODO - add loading
    this.isPlaying = false;

    //close stream if user move to another state
    this.$scope = $scope;
    this.$timeout = $timeout;
    $scope.$on('$destroy', () => this.stop());

    socket.addOptions({
      reconnectFunc: this.manageSocketEvent
    });
    this.manageSocketEvent();

    //check active stream
    if (!activeStream) {
      this.noActiveStream = true;
    } else {
      if (!_.isEmpty(currentUser) && activeStream) {
        streamingService.checkPurchased(this.activeStream._id).then(function(resp) {
          if (resp.purchased) {
            _this.purchased = true;
            _this.play();
          }
        });
      }
    }
    streamingService.countPurchaser().then(resp => this.totalJoined = resp.count);
  }

  manageSocketEvent() {
    var _this = this;
    function updateOnlineCount(data) {
      _this.onlineUser = data;
      _this.totalGuest = data.guest || 0;
      _this.totalMember = data.member ? data.member - 1 : 0;
      _this.totalOnline = _this.totalGuest + _this.totalMember;
      _this.$scope.$apply();
    }

    //listen socket event
    _this.socket.ready(function() {
      _this.socket.socketIo.emit('JOIN_ROOM', 'LIVE_STREAM');

      _this.socket.socketIo.on('NEW_SESSION_STREAM_CREATED', function(stream) {
        _this.noActiveStream = false;
        _this.activeStream = stream;
        _this.chatOptions.stream = stream;
        //_this.play();
        _this.$scope.safeApply();
      });

      _this.socket.socketIo.on('SESSION_STREAM_DESTROYED', function(stream) {
        //TODO - show alert for user.
        _this.chatOptions.stream = null;
        _this.activeStream = null;
        _this.$scope.safeApply();
      });

      _this.socket.socketIo.on('RESUME_STREAM', function(stream) {
        _this.activeStream = stream;
        //TODO - check purchased again
        if (_this.isPlaying) {
          _this.play();
        }
      });

      _this.socket.socketIo.on('NEW_USER_JOIN_ROOM', function(data) {
        updateOnlineCount(data.onlineUser);
      });

      _this.socket.socketIo.on('USER_LEAVE_ROOM', function(data) {
        updateOnlineCount(data.onlineUser);
      });

      _this.socket.socketIo.on('STATUS_CHANGE', function(data) {
        _this.status = data.status;
        _this.$scope.$apply();
      });

      //first login time
      _this.socket.socketIo.emit('COUNT_ONLINE', function(err, data) {
        updateOnlineCount(data);
      });
    });
  }

  purchase() {
    if (!this.activeStream) {
      return alert('No active stream right now!');
    }
    var _this = this;
    this.service.purchase(this.activeStream._id).then(function(resp) {
      _this.purchased = true;
      _this.play();
      _this.service.countPurchaser().then(resp => {
        _this.totalJoined = resp.count;
        _this.$scope.$apply();
      });
    }, function(err) {
      return _this.growl.error(err.data.msg);
    });
  }

  play() {
    var _this = this;

    this.streaming = new StreamingBroadcast({
      viewerElem: _this.videoElem,
      initSuccessCb: function(sessionId) {
        _this.streaming.viewer(_this.activeStream.sessionId, function(err) {
          if (!err) {
            _this.isPlaying = true;
            _this.$scope.safeApply();
          }
        });
      },
  		onDispose: function() {
  	  	//hideSpinner(video);
        _this.session = null;
        _this.treaming = null;
        //_this.noActiveStream = true;
  		},
      socket: _this.socket
    });
  }

  stop() {
    if (this.streaming) {
      this.streaming.stop();
      this.streaming.close();
    }

    this.streaming = null;
    this.session = null;
    //this.noActiveStream = true;
    this.isPlaying = false;
  }
}

angular.module('xMember')
  .controller('StreamingViewCtrl', StreamingViewCtrl);
