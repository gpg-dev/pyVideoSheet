'use strict';

angular.module('xMember').controller('BuyTokenCtrl', function($scope, $state, Auth, growl, packages) {
  $scope.packages = packages.items;

  $scope.buy = function(p) {
    if(!Auth.isLoggedIn()){
      growl.error("Please signup or login before buy this package",{ ttl:3000 });
      $state.go('login');

      return false;
    }

    $state.go('payment', {
      type: 'tokenPackage',
      package: p._id
    });
  };
});
