'use strict';

angular.module('xMember').factory('tokenService', function($http) {
  return {
    findAll() {
      return $http.get('/api/v1/tokens/packages').then(function(resp) { return resp.data; });
    },
    find(id) {
      return $http.get('/api/v1/tokens/packages/' + id).then(function(resp) { return resp.data; });
    }
  };
});
