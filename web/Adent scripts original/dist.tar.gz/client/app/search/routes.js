'use strict';

angular.module('xMember').config(function($stateProvider) {
  $stateProvider.state('search', {
    url: '/search?q?type?categoryId?r',
    templateUrl: 'app/search/search.html',
    controller: 'SearchCtrl',
    data: {
      pageTitle: 'Search',
      metaKeywords: '',
      metaDescription: 'sex, sex tour, video'
    }
  });
});
