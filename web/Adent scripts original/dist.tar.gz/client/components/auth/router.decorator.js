'use strict';

(function() {

  angular.module('xMember.auth')
    .run(function($rootScope, $state, Auth) {
      // Redirect to login if route requires auth and the user is not logged in, or doesn't have required role
      $rootScope.$on('$stateChangeStart', function(event, next, nextParams) {
        if (!next.authenticate || $rootScope.stateChangeBypass) {
          $rootScope.stateChangeBypass = false;
          return;
        }
        event.preventDefault();

        if (typeof next.authenticate === 'string') {
          Auth.hasRole(next.authenticate, _.noop)
            .then(has => {
              if (has) {
                return $state.go(next, nextParams);
              }

              return Auth.isLoggedIn(_.noop)
                .then(is => {
                  $state.go(is ? 'home' : 'login');
                });
            });
        } else {
          Auth.isLoggedIn(_.noop)
            .then(is => {
              if (!is) {
                return $state.go('login');
              }

              $rootScope.stateChangeBypass = true;
              $state.go(next, nextParams);
            });
        }
      });
    });
})();
