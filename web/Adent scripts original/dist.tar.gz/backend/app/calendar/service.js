/*global angular*/
'use strict';

angular.module('xMember').factory('scheduleService', function ($http) {
  function respondSuccess(res) {
    return res.data;
  }

  return {
    create(data) {
      return $http.post('/api/v1/schedule', data).then(respondSuccess);
    },
    update(id, data) {
      return $http.put('/api/v1/schedule/' + id, data).then(respondSuccess);
    },
    delete(id) {
      return $http.delete('/api/v1/schedule/' + id).then(respondSuccess);
    },
    list(params) {
      return $http.get('/api/v1/schedule', { params }).then(respondSuccess);
    }
  };
});
