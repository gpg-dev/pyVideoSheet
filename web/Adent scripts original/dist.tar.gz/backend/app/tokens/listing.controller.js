/*global angular*/

angular.module('xMember').controller('TokenPackageListCtrl', function($scope, $state, tokenService) {
  $scope.$state = $state;
  tokenService.list().then((resp) => $scope.items = resp.items);

  $scope.delete = function(item, $index) {
    if (!window.confirm('Are you sure?')) {
      return;
    }

    tokenService.delete(item._id).then(resp => $scope.items.splice($index, 1));
  }
});
