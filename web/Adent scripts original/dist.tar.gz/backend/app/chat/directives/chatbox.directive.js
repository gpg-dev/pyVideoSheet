'use strict';

angular.module('xMember').directive('chatbox', function($timeout, Auth, socket, messageService, tipService) {
  return {
    templateUrl: 'app/chat/views/chatbox.html',
    restrict: 'E',
    scope: {
      options: '='
    },
    link(scope, elem) {
      scope.streamerId = scope.options.streamerId;
      scope.items = [];
      scope.text = '';
      var currentUser = Auth.getCurrentUser();
      scope.currentUser = currentUser;
      scope.isDisableText = _.isEmpty(currentUser) ? true : false;
      scope.tipAmount = 1; //TODO - set min tip
      scope.isDisableTipAmount = false; //TODO - update me
      scope.availableToken = currentUser.availableToken || 0;
      var totalItem = 0;
      var page = 1;
      var pageSize = 10;
      var totalPage = 0;
      var activeStream = null;
      var chatWidgetEle = $(elem).find('.chat-widget');
      function loadList(page = 1) {
        if (scope.isLoading) {
          return;
        }

        scope.isLoading = true;
        messageService.list({ page: page }).then(resp => {
          totalPage = Math.ceil(resp.count / pageSize);
          totalItem = resp.count;
          scope.items = resp.items.reverse().concat(scope.items);
          scope.isLoading = false;

          if (page === 1) {
            $timeout(function() {
              chatWidgetEle.scrollTop(chatWidgetEle.height());
            });
          }
        });
      }

      scope.$watch('options', function(nv) {
        if (nv && nv.stream) {
          activeStream = nv.stream;
        }
      });
      $timeout(function() {
        // if (!scope.streamerId) {
        //   return;
        // }
        loadList();

        //event for scroll of the chat box to load previous message
        chatWidgetEle.scroll(function() {
          if ($(this).scrollTop() <= 10 && totalPage > page) {
            //increase page and load more
            loadList(++page);
          }
        });
      });

      scope.send = function(evt) {
        //keypress
        if (!evt || evt.which !== 13) {
          return;
        }
        if (!scope.text.trim() || _.isEmpty(currentUser)) {
          return;
        }
        scope.isDisableText = true;
        //append to the box but show sending alert
        var item = {
          streamerId: scope.streamerId,
          streamId: scope.options.stream ? scope.options.stream._id : '',
          text: scope.text,
          type: 'chat'
        };

        messageService.create(item).then(resp => {
          scope.isDisableText = false;
          scope.text = '';
        });
      };

      function manageSocketEvent() {
        //socket event
        socket.ready(function() {
          socket.socketIo.emit('JOIN_ROOM', 'GLOBAL_CHAT');
          socket.socketIo.on('NEW_CHAT_MESSAGE', function(data) {
            var index = _.findIndex(scope.items, item => item._id === data._id);
            if (index === -1) {
              scope.items.push(data);
              scope.$apply();
            }
          });

          socket.socketIo.on('NEW_USER_JOIN_ROOM', function(data) {
            if (data.roomId === 'LIVE_STREAM') {
              data.type = 'join';
              scope.items.push(data);
            }
          });
          socket.socketIo.on('USER_LEAVE_ROOM', function(data) {
            data.type = 'leave';
            scope.items.push(data);
          });
        });
      }

      socket.addOptions({
        reconnectFunc: manageSocketEvent
      });
      //manageSocketEvent();
    }
  };
});
