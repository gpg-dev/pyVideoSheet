'use strict';

angular.module('xMember.util', []);
