module.exports = async () => {
  try {
    await DB.I18nLanguage.remove();
    await DB.I18nText.remove();
    await DB.I18nTranslation.remove();

    await DB.I18nLanguage.create({
      key: 'en',
      name: 'EN',
      isDefault: true,
      isActive: true
    });
  } catch (e) {
    throw e;
  }
};
