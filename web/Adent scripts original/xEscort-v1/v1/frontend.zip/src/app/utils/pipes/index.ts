export * from './minute-to-hours.pipe';
