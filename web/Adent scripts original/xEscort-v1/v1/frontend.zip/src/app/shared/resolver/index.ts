export * from './config.resolver';
