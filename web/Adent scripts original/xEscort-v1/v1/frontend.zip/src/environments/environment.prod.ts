export const environment = {
  production: true,
  version: '0.0.1',
  build: 1,
  apiBaseUrl: 'https://xescort-api.iospot.top/v1',
  appBaseUrl: 'https://xescort.iospot.top'
};
