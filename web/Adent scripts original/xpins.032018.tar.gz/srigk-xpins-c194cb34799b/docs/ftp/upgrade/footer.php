<?php $mysqli->close();?>
</div><!--wrap-->
</body>
</html>