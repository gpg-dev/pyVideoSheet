<?php $mysqli->close();?>
</div><!--wrap-->
<div class="version footer-text">
	Copyright &#169; <?php echo date("Y");?> <?php echo $settings['name'];?>. All Rights Reserved. Build Version <?php echo $settings['build_version'];?>
</div>
</body>
</html>