<footer class="main-footer">

<!--<span>Powered by</span> <a href=""></a><span>&#8482;</span> - <a href=""></a>-->

</footer><!--main-footer-->

</div><!--container-fluid-->
</div><!--wrap-->
</body>
</html>