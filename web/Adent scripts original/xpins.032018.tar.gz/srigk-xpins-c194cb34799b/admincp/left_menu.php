<nav id="left-menu">
	<ul>
		<li><a class="fa fa-dashboard" href="index.php"><span>Dashboard</span></a></li>
		<li><a class="fa fa-cogs" href="settings.php"><span>Settings</span></a></li>
		<li class="has-sub"><a class="fa fa-file-text-o" href="#"><span>Posts</span></a>
			<ul>
				<li><a href="approved_posts.php"><span>Approved Posts</span></a></li>
				<li><a href="pending_posts.php"><span>Pending Posts</span></a></li>
				<li><a href="create_post.php"><span>Create Post</span></a></li>
			</ul>
		</li>
		<li class="has-sub"><a class="fa fa-th-large" href="#"><span>Categories</span></a>
			<ul>
				<li><a href="new_category.php"><span>Add New Category</span></a></li>
				<li><a href="manage_categories.php"><span>Manage Categories</span></a></li>
			</ul>
		</li>
		<li><a class="fa fa-users" href="users.php"><span>Users</span></a></li>
		<li><a class="fa fa-comments" href="comments.php"><span>Comments</span></a></li>
		<li><a class="fa fa-user" href="administrator.php"><span>Administrator</span></a></li>
<!--		<li><a class="fa fa-indent" href="ads.php"><span>Advertisements</span></a></li>-->
		<li class="has-sub"><a class="fa fa-th-large" href="#"><span>Advertisements</span></a>
			<ul>
				<li><a href="ads.php?page=list"><span>Home page</span></a></li>
				<li><a href="ads.php?page=post"><span>Post Page</span></a></li>
			</ul>
		</li>
		<li class="has-sub"><a class="fa fa-align-left" href="#"><span>Manage Pages</span></a>
			<ul>
				<li><a href="about.php"><span>About Page</span></a></li>
				<li><a href="privacy_policy.php"><span>Privacy Policy Page</span></a>
				<li><a href="tnc.php"><span>Terms of Use Page</span></a>
				<li><a href="dmca.php"><span>DMCA Page</span></a>
			</ul>
		</li>
		<li class="last"><a class="fa <?php echo $faIcon['view'] ?>" href="../index.html" target="_blank"><span>View Site</span></a></li>
	</ul>
</nav>