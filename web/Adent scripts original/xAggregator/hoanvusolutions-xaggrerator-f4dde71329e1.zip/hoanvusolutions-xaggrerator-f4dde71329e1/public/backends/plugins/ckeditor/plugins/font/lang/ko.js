﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'font', 'ko', {
	fontSize: {
		label: '크기',
		voiceLabel: '글자 크기',
		panelTitle: '글자 크기'
	},
	label: '글꼴',
	panelTitle: '글꼴',
	voiceLabel: '글꼴'
} );
