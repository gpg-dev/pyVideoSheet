<?php
namespace App\Observers;


class SettingObserver {
				
    public function saving($model)
    {
     
    }     
     public function deleted($model){      
      
    }
}
?>