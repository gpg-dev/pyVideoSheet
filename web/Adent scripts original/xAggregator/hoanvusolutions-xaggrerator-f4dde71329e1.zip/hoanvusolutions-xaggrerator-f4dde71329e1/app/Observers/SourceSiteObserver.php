<?php
namespace App\Observers;


class SourceSiteObserver {
				
    public function saving($model)
    {
     
    }     
     public function deleted($model){      
      
    }
}
?>