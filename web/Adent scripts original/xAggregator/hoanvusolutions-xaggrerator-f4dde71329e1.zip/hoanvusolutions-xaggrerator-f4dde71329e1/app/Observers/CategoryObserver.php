<?php
namespace App\Observers;

use App\Models\Category;

class CategoryObserver {
				
    public function saving($model)
    {
     
    }     
     public function deleted($model){      
      
    }
}
?>